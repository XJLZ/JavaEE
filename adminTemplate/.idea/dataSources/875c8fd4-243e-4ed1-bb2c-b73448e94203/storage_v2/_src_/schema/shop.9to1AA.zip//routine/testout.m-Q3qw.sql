create procedure testOut(OUT str varchar(20))
  BEGIN
	#Routine body goes here..
	   SET str='new HelloWorld';
	

END;

