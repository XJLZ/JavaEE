create procedure findUserById(IN id int)
  BEGIN
	#Routine body goes here...
SELECT * FROM s_user WHERE u_id = id;
	

END;

