create procedure testInOut(INOUT n int)
  BEGIN
	#Routine body goes here...
		 DECLARE i  INT DEFAULT 0;
		 DECLARE SUM  INT DEFAULT 0;
	   label: LOOP
					set sum=sum+i;
				  set i=i+1;
			    IF i>=n THEN
				      LEAVE label; 
			    END IF; 
		  END LOOP label;
		  set 	n = sum;
			
END;

