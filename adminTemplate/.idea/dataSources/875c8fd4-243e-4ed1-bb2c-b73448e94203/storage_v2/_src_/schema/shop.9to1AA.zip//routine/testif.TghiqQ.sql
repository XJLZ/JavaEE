create procedure testIf(IN num int, OUT str varchar(20))
  BEGIN
	#Routine body goes here...
	IF num=1 THEN
		  SET str='星期一';
	ELSEIF num=2 THEN 
	    SET str='星期二';
  ELSEIF num=3 THEN 
	    SET str='星期三';
  ELSE
      SET str='输入错误';
  END IF;

END;

