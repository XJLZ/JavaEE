create procedure testNewInOut(INOUT n int)
  BEGIN
	#Routine body goes here...
	
	#SELECT n;
  SET n =500;

END;

